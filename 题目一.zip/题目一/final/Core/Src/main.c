/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "usart.h"
#include "spi.h"
#include "tim.h"
#include "gpio.h"
#include "stdio.h"
#include "stdlib.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
uint8_t receiveData[30]={0},buff=0;
uint8_t mode=0,flag=0,real_mode=0,cult=0;
uint16_t cnt=0,time=0;
uint16_t data_index=0,cnt_index=0,time_index=0;
unsigned char talos[]="TALOS>>\r\n";
unsigned char hh[]="\r\n";
unsigned char space[]=" ";
unsigned char error[]="Input Error!!";
unsigned char off[]="LED OFF!\r\n";
unsigned char on[]="LED ON!\r\n";
char get_cnt[5]={0},get_time[5]={0};
uint8_t cnt_done=0;
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void ledBlink(int16_t count,uint16_t t)
{
	unsigned char a[]="LED blink:";
	int r=0;
	char rest[5]={0};
	char d_cnt[5]={0};
	unsigned char rest_cnt[]="	 rest:";
	for(int w=0;(w<=2*count)||(count<0);w++)
	{
			if(w%2==0)
			{
					__HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_1,1999);
			}else
			{
					__HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_1,0);
			}
		if(cult==1)break;
		HAL_Delay(t);
		r=count-w/2;
		sprintf(rest,"%d",r);
		sprintf(d_cnt,"%d",w/2);
		if(w%2==0&&receiveData[0]==0)
		{
			HAL_UART_Transmit(&hlpuart1,a,sizeof(a),100);
			HAL_UART_Transmit(&hlpuart1,(uint8_t *)d_cnt,5,100);
			if(count>0)
			{
				HAL_UART_Transmit(&hlpuart1,rest_cnt,sizeof(rest_cnt),100);
				HAL_UART_Transmit(&hlpuart1,(uint8_t *)rest,5,20);
			}
			HAL_UART_Transmit(&hlpuart1,hh,sizeof(hh),10);
		}
		if(real_mode!=3&&count<0)break;
	}
	__HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_1,0);
	HAL_UART_Transmit(&hlpuart1,talos,sizeof(talos),100);
	real_mode=0;
}
void ledbreath(int16_t count,uint16_t t)
{
	for(uint16_t i=0;(i<=count)|(count<0);i++)
	{
		int16_t direction=0;
    uint16_t brightness=0;	
		unsigned char b[]="LED breath:";
		unsigned char r[]="  rest:";
		char b_time[5]={0};
		char r_time[5]={0};
		for(int j=0;j<399;j++)
		{
			__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, brightness*10);
			while(cult==1){__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, brightness*10);}
			if (brightness >= 199) {
				direction = -1;
			} else if (brightness <= 0) {
				direction = 1;
			}
			brightness += direction;
			HAL_Delay(3);
		}
		HAL_Delay(t);
		sprintf(b_time,"%d",i);
		sprintf(r_time,"%d",count-i);
		if(receiveData[0]==0)
		{
			HAL_UART_Transmit(&hlpuart1,b,sizeof(b),30);
			HAL_UART_Transmit(&hlpuart1,(uint8_t *)b_time,5,20);
			if(count>0)
			{
				HAL_UART_Transmit(&hlpuart1,r,sizeof(r),30);
				HAL_UART_Transmit(&hlpuart1,(uint8_t *)r_time,5,20);
			}
			HAL_UART_Transmit(&hlpuart1,hh,sizeof(hh),30);
		}
		if(real_mode!=4&&count<0)break;
	}
	HAL_UART_Transmit(&hlpuart1,talos,sizeof(talos),50);
}
void Start(void)
{
	for(int i=0;i<=9;i++)
	{
	HAL_Delay(500);
		if(i%2==0)
		{
				__HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_1,1999);
		}else
		{
				__HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_1,0);
		}

		__HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_3,1000);
	}
	__HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_1,0);
	__HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_3,0);
	HAL_UART_Transmit(&hlpuart1,talos,sizeof(talos),100);
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_LPUART1_UART_Init();
  MX_TIM2_Init();
  MX_I2C1_Init();
  MX_SPI2_Init();
  MX_TIM4_Init();
  MX_TIM3_Init();
  MX_TIM1_Init();
  /* USER CODE BEGIN 2 */
	HAL_UART_Receive_IT(&hlpuart1,&buff,1);
	HAL_TIM_Base_Start_IT(&htim1);
	HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_3);
	HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_1);
	Start();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
		switch(real_mode) 
		{
			case 1:
				__HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_1,1999);
			break;
			case 2:
				__HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_1,0);
			break;
			case 3:
				ledBlink(-1,500);
			break;
			case 4:
				ledbreath(-1,500);
			break;
			case 5:
				if(cnt>0&&time>0)
				{
					ledBlink(cnt,time);
					real_mode=0;
					cnt=0;time=0;cnt_index=0;time_index=0;
				}
			break;
			case 6:
				if(cnt>0&&time>0)
				{
					ledbreath(cnt,time);
					real_mode=0;
					cnt=0;time=0;cnt_index=0;time_index=0;
				}
			break;
		}
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1_BOOST);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV4;
  RCC_OscInitStruct.PLL.PLLN = 85;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)//串口中断回调
{
	if (huart->Instance == LPUART1)
	{
		
		if(buff==3)
		{
			cult=1;buff=0;
		}else if(buff==8){
			unsigned char b[]="\033[D\033[K";
			HAL_UART_Transmit(&hlpuart1,b,sizeof(b),100);
			data_index--;buff=0;
		}else if(real_mode==5||real_mode==6)
		{
			if(buff<='9'&&buff>='0'&&cnt_done==0)
			{
				get_cnt[cnt_index++]=buff;
				HAL_UART_Transmit(&hlpuart1,&buff,1,10);
			}else if(buff==' '&&cnt_done==0){
				HAL_UART_Transmit(&hlpuart1,space,sizeof(space),10);
				cnt=atoi(get_cnt);
				cnt_done=1;
			}else if(buff<='9'&&buff>='0'&&cnt_done==1)
			{
				get_time[time_index++]=buff;
				HAL_UART_Transmit(&hlpuart1,&buff,1,10);
			}else if(buff==13&&cnt_done==1)
			{
				time=atoi(get_time);
				cnt_done=0;
			}
		}else{
			receiveData[data_index++]=buff;
			HAL_UART_Transmit(&hlpuart1,&buff,1,10);
		}
		if(buff==13)
		{
				HAL_UART_Transmit(&hlpuart1,hh,sizeof(hh),30);
			if(receiveData[0]=='l'&&receiveData[1]=='e'&&receiveData[2]=='d')
			{
				if(receiveData[3]=='O'&&receiveData[4]=='N'&&receiveData[5]==13)
				{
					mode=1;//ledON
					HAL_UART_Transmit(&hlpuart1,on,sizeof(on),100);
				}else if(receiveData[3]=='O'&&receiveData[4]=='F'&&receiveData[5]=='F'&&receiveData[6]==13)
				{
					mode=2;//ledOFF
					HAL_UART_Transmit(&hlpuart1,off,sizeof(off),100);
				}else if(receiveData[3]=='b'&&receiveData[4]=='l'&&receiveData[5]=='i'&&receiveData[6]=='n'&&receiveData[7]=='k'&&receiveData[8]==13)
				{
					mode=3;//ledblink
				}else if(receiveData[3]=='b'&&receiveData[4]=='r'&&receiveData[5]=='e'&&receiveData[6]=='a'&&receiveData[7]=='t'&&receiveData[8]=='h'&&receiveData[9]==13)
				{
					mode=4;//ledbreath
				}
			}else if(receiveData[0]=='c'&&receiveData[1]=='l'&&receiveData[2]=='e'&&receiveData[3]=='a'&&receiveData[4]=='r'&&receiveData[5]==13)
			{
				uint8_t clc[]="\033[2J\033[H";
				HAL_UART_Transmit(&hlpuart1,clc,sizeof(clc),100);
				mode=10;//clear
			}
			if(receiveData[0]!=0&&mode==0)
			{
					HAL_UART_Transmit(&hlpuart1,error,sizeof(error),50);
					mode=9;
			}
			if(mode!=10)
			HAL_UART_Transmit(&hlpuart1,talos,sizeof(talos),50);
		}
		if(receiveData[0]=='l'&&receiveData[1]=='e'&&receiveData[2]=='d'&&receiveData[3]=='c'&&receiveData[4]=='t'&&receiveData[5]=='l'&&receiveData[6]==' ')
		{
				if(receiveData[7]=='b'&&receiveData[8]=='l'&&receiveData[9]=='i'&&receiveData[10]=='n'&&receiveData[11]=='k'&&receiveData[12]==' ')
				{
								mode=5;//led有限次闪烁
				}else if(receiveData[7]=='b'&&receiveData[8]=='r'&&receiveData[9]=='e'&&receiveData[10]=='a'&&receiveData[11]=='t'&&receiveData[12]=='h'&&receiveData[13]==' ')
				{
							mode=6;//led有限次呼吸
				}else if(receiveData[7]=='O'&&receiveData[8]=='N'&&receiveData[9]==13)
				{
					mode=1;//ledON
					HAL_UART_Transmit(&hlpuart1,on,sizeof(on),100);
				}else if(receiveData[7]=='O'&&receiveData[8]=='F'&&receiveData[9]=='F'&&receiveData[10]==13)
				{
					mode=2;//ledOFF
					HAL_UART_Transmit(&hlpuart1,off,sizeof(off),100);
				}
		}else if(receiveData[0]!=0&&mode==0&&buff==13)
			{
					HAL_UART_Transmit(&hlpuart1,error,sizeof(error),50);
					mode=9;
			}
		
		if(mode!=0)
		{
			real_mode=mode;
			data_index=0;
			for(int i=0;i<30;i++)
			{
				receiveData[i]=0;
			}
			mode=0;
		}
		HAL_UART_Receive_IT(&hlpuart1,&buff,1);
	}
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
