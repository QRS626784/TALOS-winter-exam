#ifndef _BMI160_H_
#define _BMI160_H_
#include "main.h"
/**
 * @brief 存储IMU数据的结构体
 *
 */
typedef struct
{
    int16_t accel_x_raw;
    int16_t accel_y_raw;
    int16_t accel_z_raw;
    int16_t gyro_x_raw;
    int16_t gyro_y_raw;
    int16_t gyro_z_raw;//原始数据
    
    // 加速度计数据
    float accel_x;  // X轴加速度计数据
    float accel_y;  // Y轴加速度计数据
    float accel_z;  // Z轴加速度计数据
    
    // 陀螺仪数据
    float gyro_x;   // X轴陀螺仪数据
    float gyro_y;   // Y轴陀螺仪数据
    float gyro_z;   // Z轴陀螺仪数据
    
    // 四元数数据
    float quaternion_w; // 四元数的实部
    float quaternion_x; // 四元数的虚部 i
    float quaternion_y; // 四元数的虚部 j
    float quaternion_z; // 四元数的虚部 k
    
    // 欧拉角数据
    float roll;     // 滚转角
    float pitch;    // 俯仰角
    float yaw;      // 偏航角
    
    //上一次的欧拉角
    float last_roll;     // 滚转角
    float last_pitch;    // 俯仰角
    float last_yaw;      // 偏航角

    uint32_t updatetime;    // 更新数据的时间戳
    uint32_t lastupdatetime; // 上次更新数据的时间戳

} imu_data_t;
uint8_t usr_bmi160_init(void);
uint8_t bmi160_update(imu_data_t* data);
uint8_t eular_update(imu_data_t *data);
extern struct bmi160_dev sensor;
#endif