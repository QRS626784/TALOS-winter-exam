#ifndef _BSP_LIS3MDL_H_
#define _BSP_LIS3MDL_H_
#include "main.h"

typedef struct 
{
    int16_t mag_x_raw;
    int16_t mag_y_raw;
    int16_t mag_z_raw;
    float mag_x;
    float mag_y;
    float mag_z;

}mag_data_t;

uint8_t lis3mdl_get_chip_id(void);
uint8_t lis3mdl_read_data(mag_data_t *mag_data);
void lis3mdl_init(void);

#endif